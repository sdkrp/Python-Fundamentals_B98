package com.company.traffic.model;



public class TrafficLight {

    private final Direction direction;
    private LightState state;

    public TrafficLight(Direction direction) {
        this.direction = direction;
        this.state = LightState.RED;
    }

    public synchronized void changeState(LightState newState) {
        this.state = newState;
    }

    public LightState getState() {
        return state;
    }

    public Direction getDirection() {
        return direction;
    }
}

