package com.company.traffic.service;

import com.company.traffic.model.*;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Service
public class TrafficController {

    private final Map<Direction, TrafficLight> lights = new ConcurrentHashMap<>();

    public TrafficController() {
        for (Direction direction : Direction.values()) {
            lights.put(direction, new TrafficLight(direction));
        }
    }

    public synchronized void setGreen(Direction direction) {
        validateNoConflict(direction);
        lights.get(direction).changeState(LightState.GREEN);
    }

    private void validateNoConflict(Direction direction) {

        if (direction == Direction.NORTH || direction == Direction.SOUTH) {

            if (lights.get(Direction.EAST).getState() == LightState.GREEN ||
                    lights.get(Direction.WEST).getState() == LightState.GREEN) {
                throw new IllegalStateException("Conflict detected!");
            }

        } else { // EAST or WEST

            if (lights.get(Direction.NORTH).getState() == LightState.GREEN ||
                    lights.get(Direction.SOUTH).getState() == LightState.GREEN) {
                throw new IllegalStateException("Conflict detected!");
            }
        }
    }

    public Map<Direction, LightState> currentState() {
        return lights.entrySet()
                .stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        e -> e.getValue().getState()
                ));
    }
}
