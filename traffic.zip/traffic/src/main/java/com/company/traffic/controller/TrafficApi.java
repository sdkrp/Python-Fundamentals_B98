package com.company.traffic.controller;

import com.company.traffic.model.*;
import com.company.traffic.service.TrafficController;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/traffic")
public class TrafficApi {

    private final TrafficController controller;

    public TrafficApi(TrafficController controller) {
        this.controller = controller;
    }

    @PostMapping("/green/{direction}")
    public void makeGreen(@PathVariable Direction direction) {
        controller.setGreen(direction);
    }

    @GetMapping("/state")
    public Map<Direction, LightState> getState() {
        return controller.currentState();
    }
}
