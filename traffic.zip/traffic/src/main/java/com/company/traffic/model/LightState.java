package com.company.traffic.model;



public enum LightState {
    RED,
    YELLOW,
    GREEN
}
