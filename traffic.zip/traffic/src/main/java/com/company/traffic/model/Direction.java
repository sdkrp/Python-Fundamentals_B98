package com.company.traffic.model;

public enum Direction {
    NORTH,
    SOUTH,
    EAST,
    WEST
}
