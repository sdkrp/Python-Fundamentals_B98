package com.company.traffic;

import com.company.traffic.model.Direction;
import com.company.traffic.service.TrafficController;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TrafficControllerTest {

    private final TrafficController controller = new TrafficController();

    @Test
    void shouldRejectConflictingGreen() {
        controller.setGreen(Direction.NORTH);

        assertThrows(IllegalStateException.class,
                () -> controller.setGreen(Direction.EAST));
    }
}
